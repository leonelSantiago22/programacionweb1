export const environment = {
    production: false,
    //declariacion de la variable global, con el siguiente atributo:
    API_URI: "http://localhost:3000",
};
    