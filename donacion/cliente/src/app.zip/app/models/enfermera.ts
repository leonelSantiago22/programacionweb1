export class Enfermera {
  numero_trabajador: number;
  idhospital: number;
  idpersona: number;
  password: string;
   constructor() {
    this.numero_trabajador = 1;
    this.idhospital = 0;
    this.idpersona = 0;
    this.password = 'password';
  }
}
