import { Component } from '@angular/core';

@Component({
  selector: 'app-transfuciones',
  templateUrl: './transfuciones.component.html',
  styleUrls: ['./transfuciones.component.css']
})
export class TransfucionesComponent {

}
