export class Transfucion {
    idsolicitud: number;
    idpaciente: number;
    fecha: string;
     constructor() {
        this.idpaciente = 0;
        this.idsolicitud = 0;
        this.fecha  = 'yyyy/mm/dd';
    }
  }
  