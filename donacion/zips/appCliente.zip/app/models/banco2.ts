export class Bancos2 {
    idbanco?: number;
    nombre?:string;
    iddonacion?:number;
    fecha_donacion?:string;
    idregistro?:number;
     constructor() {
      }
  }
  