
do
{
   item = 10;
   value = value + item; 
} while(value<100);

Item = 10;
do
{
   value = value + item; 
} while(value<100);