export class Persona {
    idpersona: number;
    nombre: string;
    edad: number;
    genero: string;
    iddonador: number;
     constructor() {
      this.idpersona = 0;
      this.nombre =  "";
      this.edad = 0;
      this.genero = 'M/F'
      this.iddonador = 0;
    }
  }
  