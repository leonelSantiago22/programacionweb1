export class Donacion {
    iddonacion?:number;
    iddonador?:number;
    banco?:number;
     constructor() {
      
    }
}
  