export class Enfermera {
    numero_trabajador: number;
    password: string;
    nombre:string;
     constructor() {
      this.numero_trabajador = 2;
      this.password = 'password';
      this.nombre = 'nombre';
    }
  }
  