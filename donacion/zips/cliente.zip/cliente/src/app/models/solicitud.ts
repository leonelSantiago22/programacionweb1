export class Solicitud {
    idsolicitud: number;
    idbanco: number;
    fecha: string;
    estado: number;
    idhospital: number;
    numero_trabajador: number;
     constructor() {
        this.idsolicitud = 0;
        this.idbanco = 0;
        this.fecha =  "12/12/2002";
        this.estado = 0;
        this.idhospital = 0;
        this.numero_trabajador =  0;

    }
  }
  