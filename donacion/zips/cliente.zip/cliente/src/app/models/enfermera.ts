export class Enfermera {
  numero_trabajador?: number;
  idhospital?: number;
  idpersona?: number;
  password?: string;
  nombre?: string;
  edad?:number;
  genero?:string;
   constructor() {

  }
}
