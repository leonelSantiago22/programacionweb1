export class Bolsadesangre {
    idbolsa:number;
    cantidad:number;
    tipodesangre: string;
    idregistro: number;
     constructor() {
        this.idbolsa = 0;
        this.cantidad = 0;
        this.tipodesangre = 'O-Rh+';
        this.idregistro = 0;
    }
}
  