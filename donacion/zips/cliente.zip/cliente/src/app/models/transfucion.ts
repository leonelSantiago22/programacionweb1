export class Transfucion {
    idsolicitud?: number;
    idpaciente?: number;
    fecha?: string;
     constructor() {
     
    }
  }
  