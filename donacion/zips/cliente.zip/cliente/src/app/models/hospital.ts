export class Hospital {
    idhospital?: number;
    Nombre?:string;
    Direccion?: string;
     constructor() {
      }
}
  